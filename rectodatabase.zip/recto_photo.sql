-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: k4a204.p.ssafy.io    Database: recto
-- ------------------------------------------------------
-- Server version	8.0.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `photo`
--

DROP TABLE IF EXISTS `photo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `photo` (
  `photo_seq` int NOT NULL AUTO_INCREMENT,
  `user_uid` varchar(100) NOT NULL,
  `photo_id` varchar(10) NOT NULL,
  `photo_date` date DEFAULT NULL,
  `photo_url` longtext,
  `video_url` longtext,
  `phrase` varchar(50) DEFAULT NULL,
  `photo_pwd` varchar(100) DEFAULT NULL,
  `design` int NOT NULL,
  PRIMARY KEY (`photo_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=154 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `photo`
--

LOCK TABLES `photo` WRITE;
/*!40000 ALTER TABLE `photo` DISABLE KEYS */;
INSERT INTO `photo` VALUES (1,'admin','204071765','2021-05-08','https://project-recto.s3.ap-northeast-2.amazonaws.com/samplephoto9.png','https://project-recto.s3.ap-northeast-2.amazonaws.com/204071765.mp4',NULL,'',1),(2,'admin','204402789','2021-03-01','https://project-recto.s3.ap-northeast-2.amazonaws.com/samplephoto5.png','https://project-recto.s3.ap-northeast-2.amazonaws.com/204402789.mp4','','',1),(3,'admin','204123101','2021-05-12','https://project-recto.s3.ap-northeast-2.amazonaws.com/samplephoto8.png','https://project-recto.s3.ap-northeast-2.amazonaws.com/204123101.mp4','파뤼투나잇','',2),(4,'admin','204012025','2021-05-12','https://project-recto.s3.ap-northeast-2.amazonaws.com/samplephoto6.png','https://project-recto.s3.ap-northeast-2.amazonaws.com/204012025.mp4','','',1),(5,'admin','204050801','2021-05-12','https://project-recto.s3.ap-northeast-2.amazonaws.com/samplephoto7.png','https://project-recto.s3.ap-northeast-2.amazonaws.com/204050801.mp4','엄마 사랑해♥','',2),(6,'admin','185320152','2021-03-01','https://project-recto.s3.ap-northeast-2.amazonaws.com/samplephoto2.png','https://project-recto.s3.ap-northeast-2.amazonaws.com/185320152.mp4','','',1),(7,'admin','204228419','2021-03-01','https://project-recto.s3.ap-northeast-2.amazonaws.com/samplephoto4.png','https://project-recto.s3.ap-northeast-2.amazonaws.com/204228419.mp4','콧물 방울 보리','',2),(8,'admin','185320153','2021-03-01','https://project-recto.s3.ap-northeast-2.amazonaws.com/samplephoto3.png','https://project-recto.s3.ap-northeast-2.amazonaws.com/185320153.mp4','Happy Birthday','',2),(9,'admin','185320151','2021-05-09','https://project-recto.s3.ap-northeast-2.amazonaws.com/samplephoto.png','https://project-recto.s3.ap-northeast-2.amazonaws.com/185320151.mp4','','',1),(10,'admin','210101417','2021-05-19','https://project-recto.s3.ap-northeast-2.amazonaws.com/210101417_image.jpg','https://project-recto.s3.ap-northeast-2.amazonaws.com/210101417_video.mp4',NULL,NULL,1),(11,'admin','201225417','2021-05-18','https://project-recto.s3.ap-northeast-2.amazonaws.com/201225417_image.jpg','https://project-recto.s3.ap-northeast-2.amazonaws.com/201225417_video.mp4','Merry X-mas',NULL,2),(12,'admin','200601417','2021-05-18','https://project-recto.s3.ap-northeast-2.amazonaws.com/200601417_image.jpg','https://project-recto.s3.ap-northeast-2.amazonaws.com/200601417_video.mp4',NULL,NULL,1),(100,'79Im3gIZg7QRb5zCsWiUc3bw5w92','200103000','2021-05-16','https://project-recto.s3.ap-northeast-2.amazonaws.com/200103000.png','https://project-recto.s3.ap-northeast-2.amazonaws.com/200103000.mp4',NULL,NULL,1),(101,'79Im3gIZg7QRb5zCsWiUc3bw5w92','210415004','2021-05-16','https://project-recto.s3.ap-northeast-2.amazonaws.com/210415004.png','https://project-recto.s3.ap-northeast-2.amazonaws.com/210415004.mp4',NULL,NULL,1),(102,'79Im3gIZg7QRb5zCsWiUc3bw5w92','190111417','2021-05-16','https://project-recto.s3.ap-northeast-2.amazonaws.com/190111417.png','https://project-recto.s3.ap-northeast-2.amazonaws.com/190111417.mp4',NULL,NULL,1),(103,'79Im3gIZg7QRb5zCsWiUc3bw5w92','190408001','2021-05-16','https://project-recto.s3.ap-northeast-2.amazonaws.com/190408001.png','https://project-recto.s3.ap-northeast-2.amazonaws.com/190408001.mp4','2019년 학교 벚꽃',NULL,2),(104,'79Im3gIZg7QRb5zCsWiUc3bw5w92','210223128','2021-05-16','https://project-recto.s3.ap-northeast-2.amazonaws.com/210223128.png','https://project-recto.s3.ap-northeast-2.amazonaws.com/210223128.mp4',NULL,NULL,1),(105,'79Im3gIZg7QRb5zCsWiUc3bw5w92','000000000','2021-05-16','https://project-recto.s3.ap-northeast-2.amazonaws.com/000000000.png','https://project-recto.s3.ap-northeast-2.amazonaws.com/000000000.mp4',NULL,'1234',1),(106,'79Im3gIZg7QRb5zCsWiUc3bw5w92','210401142','2021-05-16','https://project-recto.s3.ap-northeast-2.amazonaws.com/210401142.png','https://project-recto.s3.ap-northeast-2.amazonaws.com/210401142.mp4',NULL,'1234',1),(107,'OHKMJKbh3pNWTM6ZrY4z9qKpPBI3','201128417','2021-05-16','https://project-recto.s3.ap-northeast-2.amazonaws.com/201128417.png','https://project-recto.s3.ap-northeast-2.amazonaws.com/201128417.mp4',NULL,NULL,1),(108,'79Im3gIZg7QRb5zCsWiUc3bw5w92','210420123','2021-05-16','https://project-recto.s3.ap-northeast-2.amazonaws.com/210420123.png','https://project-recto.s3.ap-northeast-2.amazonaws.com/210420123.mp4','예쁜 노을 :>',NULL,2),(110,'79Im3gIZg7QRb5zCsWiUc3bw5w92','210428021','2021-05-16','https://project-recto.s3.ap-northeast-2.amazonaws.com/210428021.png','https://project-recto.s3.ap-northeast-2.amazonaws.com/210428021.mp4',NULL,NULL,1),(111,'79Im3gIZg7QRb5zCsWiUc3bw5w92','200608128','2021-05-16','https://project-recto.s3.ap-northeast-2.amazonaws.com/200608128.png','https://project-recto.s3.ap-northeast-2.amazonaws.com/200608128.mp4',NULL,NULL,1),(113,'79Im3gIZg7QRb5zCsWiUc3bw5w92','210426228','2021-05-16','https://project-recto.s3.ap-northeast-2.amazonaws.com/210426228.png','https://project-recto.s3.ap-northeast-2.amazonaws.com/210426228.mp4','보리야 공부 열심히 하자',NULL,2),(114,'79Im3gIZg7QRb5zCsWiUc3bw5w92','210425417','2021-05-16','https://project-recto.s3.ap-northeast-2.amazonaws.com/210425417.png','https://project-recto.s3.ap-northeast-2.amazonaws.com/210425417.mp4',NULL,NULL,1),(115,'79Im3gIZg7QRb5zCsWiUc3bw5w92','999999999','2021-05-16','https://project-recto.s3.ap-northeast-2.amazonaws.com/999999999.png','https://project-recto.s3.ap-northeast-2.amazonaws.com/999999999.mp4',NULL,NULL,1),(116,'OHKMJKbh3pNWTM6ZrY4z9qKpPBI3','210419128','2021-05-16','https://project-recto.s3.ap-northeast-2.amazonaws.com/210419128.png','https://project-recto.s3.ap-northeast-2.amazonaws.com/210419128.mp4',NULL,NULL,1);
/*!40000 ALTER TABLE `photo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-05-21  3:27:25
